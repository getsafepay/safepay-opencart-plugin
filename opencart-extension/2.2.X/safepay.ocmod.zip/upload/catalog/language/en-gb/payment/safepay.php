<?php
// Text
$_['text_title']       = 'Safepay Checkout <br /><small>- Pay with your credit or debit card</small>';
$_['text_sandbox_mode_enable'] = 'Sandbox Mode is enable. No transaction will be charge to your account.';
$_['text_currency_not_supported'] = 'This store have currencies not supported by Safepay. Go back, and select another payment method.';
